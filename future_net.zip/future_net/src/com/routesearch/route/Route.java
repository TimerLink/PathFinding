package com.routesearch.route;

import java.util.*;

public final class Route
{
    /**
     * 你需要完成功能的入口
     *
     * @author XXX
     * @since 2016-3-4
     * @version V1
     */
    public static int[][] numMatrix;        //标号矩阵//邻接矩阵
    private static int vertexNum = 0;
    private static int vertexNum1 = 0;
    private static final int INFINITE = 10000;
    public static Vertex point[];
    public static Routeway pathway[];
    public static int SourceID;
    public static int DestinationID;
    public  static int pointV[];
    public static String[]graphArray;

    public static String searchRoute(String graphContent, String condition)
    {
        graphArray = graphContent.split("\n"); //内容字符串按行分割，每行为每条边的信息
        for (int i = 0; i < graphArray.length; i++) {
            String str[] = graphArray[i].split(",");
            vertexNum1 = Math.max(Integer.parseInt(str[1]), Integer.parseInt(str[2]));
            if (vertexNum1 > vertexNum) {
                vertexNum = vertexNum1;
            }
        }

        point = new Vertex[vertexNum + 1];
        int[][] edges = new int[vertexNum + 1][vertexNum + 1];  //初始化邻接矩阵,将邻接矩阵内的值均设为无穷大
        numMatrix = new int[vertexNum + 1][vertexNum + 1];
        for (int i = 0; i <= vertexNum; i++) {
            for (int j = 0; j <= vertexNum; j++) {
                edges[i][j] = INFINITE;
                numMatrix[i][j] = INFINITE;
            }
        }
        /*解决两点之间多条路径的冲突*/
        for (int i = 0; i < graphArray.length; i++) {
            String str2[] = graphArray[i].split(",");
            for (int j = 0; j < graphArray.length; j++) {
                if (j == i) {
                    continue;
                }
                String str3[] = graphArray[j].split(",");
                if (str2[1] == str3[1] && str2[2] == str3[2]) {
                    if (Integer.parseInt(str2[3]) < Integer.parseInt(str3[3])) {
                        str3[3] = str2[3];
                        str3[1] = str2[1];
                    } else {
                        str2[3] = str3[3];
                        str2[1] = str3[1];
                    }
                }
            }
        }
        /*给矩阵和路类赋值*/
        pathway = new Routeway[graphArray.length];
        List<Routeway> routes = new ArrayList<>();
        for (int i = 0; i < graphArray.length; i++) {
            String str2[] = graphArray[i].split(",");
            edges[Integer.parseInt(str2[1])][Integer.parseInt(str2[2])] = Integer.parseInt(str2[3]);
            numMatrix[Integer.parseInt(str2[1])][Integer.parseInt(str2[2])] = Integer.parseInt(str2[0]);
            pathway[i] = new Routeway(str2[0], Integer.parseInt(str2[3]), point[Integer.parseInt(str2[1])], point[Integer.parseInt(str2[2])]);
            routes.add(pathway[i]);
        }
        String conditionA[] = condition.split("\n");
        String[] conditionArray = conditionA[0].split(","); //条件字符串按逗号分开，格式为0，1，2|3|4|5
        SourceID = Integer.parseInt(conditionArray[0]); //获取起始点
        DestinationID = Integer.parseInt(conditionArray[1]);//获取终止点
        /*获取途经点*/
        String conditionPart = conditionArray[2];
        String[] conditionPass = conditionPart.split("\\|");
        pointV = new int[conditionPass.length];
        for (int i = 0; i < conditionPass.length; i++) {
            pointV[i] = Integer.parseInt(conditionPass[i]);
        }
        List<Vertex> vertexs = new ArrayList<Vertex>();
        for (int i = 0; i <= vertexNum; i++) {
            String a2 = Integer.toString(i);
            point[i] = new Vertex(a2);
            vertexs.add(point[i]);
        }
        /*初始化完成，进行图操作
        * search 操作需要判断是否可以走通*/
        Graph graph = new Graph(vertexs, edges, routes);
        /*随机优化*/
        /*循环初始化*/
        int minTotalValue = INFINITE - 1;
        int countMin = 0;
        double maxValue = 0;//得到最远路径点
        double valueV[] = new double[pointV.length];//用于存储顺序权值
        boolean pointRepeated;
        List<String> routeSelect = new ArrayList<String>();//存储最终打印路径信息
        /*权值归一化*/
        for(int i=0;i<pointV.length;i++){
            valueV[i] = point[pointV[i]].getPath();
            if (point[pointV[i]].getPath()>maxValue){
                maxValue = point[pointV[i]].getPath();
            }
        }
        for(int i=0;i<pointV.length;i++){
            valueV[i] = (maxValue-point[pointV[i]].getPath())/maxValue;
        }
        int b1 = pointV.length;
        double valueStore[] = new double[b1];//存储相应的权值
        int pointVChange[] = new int [b1];
        for (int i=0;i<b1;i++){
            valueStore[i] = valueV[i];
            pointVChange[i] = pointV[i];
        }
        List<Integer> pointVReplace = new ArrayList<>();
        for (int i=0;i<pointV.length;i++){
            pointVReplace.add(pointV[i]);
        }
        sort(pointVReplace, new ArrayList());
        int size = strList.size();
        int countMax = size;
        int frame = 0;
        for (int i=0;i<b1-1;i++){
            for (int j=i+1;j<b1;j++){
                if (valueV[i]<valueV[j]){
                    double temp = valueV[i];
                    valueV[i] = valueV[j];
                    valueV[j] = temp;
                }
            }
        }
        for (int i = 0; i < b1; i++) {
            valueStore[i] = valueV[i];
        }
        int totalValue;

        /*初始化结束
        * 进入循环*/
        while (frame<size&&countMin<countMax) {
            int i2 = 0;
            for (int i = frame; i < b1+frame; i++) {
                pointVChange[i2] = strList.get(i);
                i2++;
            }
            frame = frame + b1;
            List<Integer> pointViaValue = valueSort(pointVChange, valueStore);//按权值进行排序
            pointViaValue.add(0, SourceID);
            pointViaValue.add(DestinationID);
            pointRepeated = graph.searchRepeat(pointViaValue);//判断是否有重复点
            if (!pointRepeated){
                totalValue = graph.searchValue(pointViaValue);//获取该顺序路径权值
                if (totalValue < minTotalValue) {
                    routeSelect.removeAll(routeSelect);
                    List<String> singleRoute = graph.searchTo(pointViaValue);
                    routeSelect.addAll(singleRoute);
                    minTotalValue = totalValue;
                    if (size>5000) {
                        break;
                    }
                    countMin = countMin+vertexNum*40;
                }
                countMin = countMin+20;
            }
            countMin = countMin + b1;
        }
//        System.out.print("frame:"+frame);
        String shortestCut = "";
        for (int i=0;i<routeSelect.size();i++){
            if (i<routeSelect.size()-1) {
                shortestCut = shortestCut + routeSelect.get(i) + "|";
            }
            else {
                shortestCut = shortestCut + routeSelect.get(i);
            }
        }
//        if (shortestCut.length()>0) {
//            System.out.println("最短路径为:" + shortestCut + " 最小权重为:" + minTotalValue);
//        }
//        else {
//            System.out.println("最短路径为:" + "NA" + " 最小权重为:" + minTotalValue);
//        }

        if (shortestCut.length()>0) {
            return ("最短路径为:" + shortestCut );
        }
        else {
            return ("最短路径为:" + "NA");
        }
    }

    public static List<Integer> strList = new ArrayList<>();
    private static void sort(List<Integer> datas,List<Integer> target) {
        if (target.size() == pointV.length) {
            for (Integer obj : target) {
                strList.add(obj);
            }
        }
        for (int i = 0; i < datas.size(); i++) {
            List<Integer> newDatas = new ArrayList<>(datas);
            List<Integer> newTarget = new ArrayList<>(target);
            newTarget.add(newDatas.get(i));
            newDatas.remove(i);
            sort(newDatas, newTarget);
        }
    }
    /*按权值进行排序*/
    public static List<Integer> valueSort(int pointV[],double value[]){
        List<Integer> pointVia = new ArrayList<>();
        for(int i=1;i<pointV.length;i++){
            for(int j=0;j<pointV.length-i;j++){
                if(value[j]<value[j+1]){
                    double temp = value[j];
                    value[j] = value[j+1];
                    value[j+1] = temp;
                    int temp2 = pointV[j];
                    pointV[j] = pointV[j+1];
                    pointV[j+1] = temp2;
                }
            }
        }
        for(int i=0;i<pointV.length;i++){
            pointVia.add(pointV[i]);
        }
        return pointVia;
    }
    //声明顶点类

    public static class Vertex implements Comparable<Vertex>{

        /**
         * 节点名称(A,B,C,D)
         */
        public String name;

        /**
         * 最短路径长度
         */
        public int path;

        public Vertex(String name){
            this.name = name;
            this.path = INFINITE; //初始设置为无穷大
        }

        @Override
        public int compareTo(Vertex o) {
            return o.path > path?-1:1;
        }
        public int getPath(){
            return path;
        }
        public void setPath(int path){
            this.path=path;
        }
    }

    /*声明路类*/
    public static class Routeway{
        public String name;
        public int value;
        public boolean routeMarked;
        public Vertex souID;
        public Vertex desID;
        public void setRouteMarked(boolean bln){
            this.routeMarked = bln;
        }
        public boolean isRouteMarked(){
            return routeMarked;
        }
        public  Routeway(String name,int value,Vertex souID,Vertex desID){
            this.name = name;
            this.value = value;
            this.souID = souID;
            this.desID = desID;
            this.routeMarked = false;
        }
    }

    /*声明图类*/
    public static class Graph {

        /*
         * 顶点
         */
        private List<Vertex> vertexs;

        /*
         * 边
         */
        private int[][] edges;

        private List<Routeway> routes;

        /*
         * 没有访问的顶点
         */
        public Graph(List<Vertex> vertexs, int[][] edges, List<Routeway> routes) {
            this.vertexs = vertexs;
            this.edges = edges;
            this.routes = routes;
        }
        public int searchValue(List<Integer> passPoints){
            List<String> passRoutes = searchTo(passPoints);
            int valueSum = calcValue(passRoutes);
            return valueSum;
        }

        public int calcValue(List<String> passRoutes){
            int valueSum = 0;
            for (String passRoute : passRoutes) {
                if (!passRoute.equals("INFINITE")) {
                    valueSum = valueSum + pathway[Integer.parseInt(passRoute)].value;
                }
                else {
                    valueSum = valueSum + INFINITE;
                }
            }
            return valueSum;
        }

        public List<String> searchTo(List<Integer> passPoints){
            List<String> passRoutes = new ArrayList<>();
            for(int i=0;i<passPoints.size()-1;i++){
                List<String> pastRs = searchTo(passPoints.get(i),passPoints.get(i+1));
                if (pastRs.size()>0) {
                    passRoutes.addAll(pastRs);
                }
                else {
                    passRoutes.add("INFINITE");
                }
            }
            return passRoutes;
        }
        public boolean searchRepeat(List<Integer> passPoints){
            List<Vertex> pastNeighbors = new ArrayList<>();
            for(int i=0;i<passPoints.size()-1;i++){
                search(point[passPoints.get(i)]);
                List<Vertex> pastNeighborParts = searchReturn(point[passPoints.get(i)],point[passPoints.get(i+1)]);
                pastNeighbors.addAll(pastNeighborParts);
            }
            boolean isRepeated = false;
            loop:for(int i=0;i<pastNeighbors.size()-1;i++){
                for (int j=i+1;j<pastNeighbors.size();j++){
                    if(pastNeighbors.get(i)==pastNeighbors.get(j)) {
                        isRepeated = true;
                        break loop;
                    }
                }
            }
            return isRepeated;
        }
        /*searchTo方法打印路径和获取路径*/
        public List<String> searchTo(int pastA,int pastB){
            List<String> pastRoutes =new ArrayList<>();
            search(point[pastA]);
            List<Vertex> pastNeighbors = searchReturn(point[pastA],point[pastB]);
            if (pastNeighbors.size()>0) {
                pastNeighbors.add(0, point[pastB]);
                for (int i = pastNeighbors.size() - 1; i > 0; i--) {
                    int former = vertexs.indexOf(pastNeighbors.get(i));
                    int latter = vertexs.indexOf(pastNeighbors.get(i - 1));
                    pastRoutes.add(Integer.toString(numMatrix[former][latter]));
                }
            }
            return pastRoutes;
        }
        /*
         * 搜索各顶点最短路径
         */
        public void search(Vertex anyID){
            initial();
            Vertex vertex = anyID;
            vertex.setPath(0);
            List<Vertex> vertexList = new ArrayList<>();
            vertexList.add(vertex);
            List<Vertex> neighbors = getNeighbors(vertex);
            List<Vertex> neighborSeconds = new ArrayList<Vertex>();
            int countI = 0;
            int maxRoutesCount = 1;
            while (countI<graphArray.length&&countI!=maxRoutesCount) {
                maxRoutesCount = countI;
                neighborSeconds.removeAll(neighborSeconds);
                for (Vertex neighbor : neighbors) {
                    for(Vertex vertex1:vertexList) {
                        updateDistance(vertex1, neighbor);
                        int numMat = numMatrix[vertexs.indexOf(vertex1)][vertexs.indexOf(neighbor)];
                        if(numMat<=graphArray.length) {
                            if (!routes.get(numMat).isRouteMarked()) {
                                routes.get(numMat).setRouteMarked(true);
                                countI++;
                            }
                        }
                    }
                    List<Vertex> neighborParts = getNeighbors(neighbor);
                    neighborSeconds.addAll(neighborParts);
                }
                vertexList.removeAll(vertexList);
                vertexList.addAll(neighbors);
                neighbors.removeAll(neighbors);
                neighbors.addAll(neighborSeconds);
            }
        }
        /*对顶点和路标初始化*/
        public void initial(){
            for (Vertex vertex:vertexs){
                vertex.setPath(INFINITE);
            }
            for (Routeway routeway:routes){
                routeway.setRouteMarked(false);
            }
        }
        public List<Vertex> searchReturn(Vertex anySource,Vertex letter){
            int distance1 = letter.getPath();
            List<Vertex> neighborRs = getNeighborRs(letter);
            List<Vertex> neighborRLists = new ArrayList<>();
            if (distance1<INFINITE) {
                while (letter != anySource) {
                    for (Vertex neighborR : neighborRs) {
                        if (distance1 >= neighborR.getPath() + getDistance(neighborR, letter)) {
                            int newPath = neighborR.getPath() + getDistance(neighborR, letter);
                            neighborRLists.add(neighborR);
                            letter = neighborR;
                            if (distance1 > newPath) {
                                letter.setPath(newPath);
                            }
                            distance1 = newPath;
                        }
                    }
                    neighborRs.removeAll(neighborRs);
                    neighborRs = getNeighborRs(letter);
                }
            }
            return neighborRLists;
        }

        /*
         * 更新邻居的最短路径~~~最终得到A的邻居到起点的距离
         */
        private void updateDistance(Vertex vertex, Vertex neighbor){
            int distance = getDistance(vertex, neighbor) + vertex.getPath();//索引点到邻居的距离+索引点到起点的距离
            if(distance < neighbor.getPath()){              //如果距离小于邻居到起点的距离
                neighbor.setPath(distance);                 //把距离传进路径中
            }
        }

        /*
         * 获取顶点到目标顶点的距离
         */
        public int getDistance(Vertex source, Vertex destination) {
            int sourceIndex = vertexs.indexOf(source);
            int destIndex = vertexs.indexOf(destination);
            return edges[sourceIndex][destIndex];
        }

        /*
         * 获取顶点所有(未访问的)邻居~~~这里可以进行邻居距离的比较
         */
        private List<Vertex> getNeighbors(Vertex v) {
            List<Vertex> neighbors = new ArrayList<Vertex>();
            int position = vertexs.indexOf(v);//返回首次出现v的索引
            Vertex neighbor;
            int distance;
            for (int i = 0; i < vertexs.size(); i++) {
                if (i == position) {
                    //顶点本身，跳过
                    continue;
                }
                distance = edges[position][i];    //到所有顶点的距离
                //这里通过for循环可以得到最小的那个邻居
                if (distance < 10000) {
                    //是邻居(有路径可达)
                    neighbor = getVertex(i);//如果邻居没有访问过，则加入list;
                    neighbors.add(neighbor);
                }
            }
            return neighbors;
        }
        private  List<Vertex> getNeighborRs(Vertex v){
            List<Vertex> neighborRs = new ArrayList<Vertex>();
            int position = vertexs.indexOf(v);
            Vertex neighborR;
            int distance2;
            for (int i=0;i<vertexs.size();i++){
                if (i==position){
                    continue;
                }
                distance2=edges[i][position];
                if (distance2<INFINITE){
                    neighborR = getVertex(i);
                    neighborRs.add(neighborR);
                }
            }
            return neighborRs;
        }
        /*
         * 根据顶点位置获取顶点
         */
        private Vertex getVertex(int index) {
            return vertexs.get(index);
        }
    }
}